1,000,000

## **1**,000,000 through **2,147**,000,000
Category that the item falls into. For example, gun, ammo, material, etc.

## 1,**000**,000 through 1,**999**,000
Specific item within the category that the item model falls into. For example, a Glock 18c and FAMAS would go into this category within guns.
