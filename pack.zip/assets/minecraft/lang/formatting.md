# Template
"upgrade.race.creep.title.1": "",
"upgrade.race.creep.description.1": "",

# Syntax

There should be 5 whitespaces between each race's upgrades

Two whitespaces between each tier one upgrade

One whitespace and an indent prededing higher tier upgrades
