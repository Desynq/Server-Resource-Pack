# Server Resource Pack
- Used for my private servers

## Asset Credits (Incomplete)
- A lot of anonymous users from NovaSkins.me for most of the skins
- Wynncraft Team
    - Vortex Armor
- Hunajameloni : [Warfare Resource Pack](https://www.planetminecraft.com/texture-pack/block-ops-zombies/)
    - Some of the 3D guns
- Tinkers Construct
- Thaumcraft
    - Some item textures
- Minefactory Reloaded
- Mekanism
- Botania
    - WorldEdit Wand
- DannyBeisner
    - Most of the high-poly guns
- Hypixel
    - Some gun models
